Font Mfizz by Fizzed
=======================================

 - [Fizzed, Inc.](http://fizzed.com) (Follow on Twitter: [@fizzed_inc](http://twitter.com/fizzed_inc))

#### 2.4.1 - 2017-02-13

 - Fix azure, heroku, npm, sass, and rust spacing
 - Fix gulp-alt outline

#### 2.4.0 - 2017-02-13

 - Added icon-go
 - Added icon-go-alt
 - Added icon-rust
 - Added icon-alpinelinux
 - Added icon-html5-alt
 - Added icon-html5-alt2
 - Added icon-azure
 - Added icon-css3-alt
 - Added icon-css3-alt2
 - Added icon-elm
 - Added icon-openshift
 - Added icon-magento
 - Added icon-git
 - Added icon-x11
 - Added icon-gulp
 - Added icon-gulp-alt
 - Added icon-grunt
 - Added icon-npm
 - Added icon-sass
 - Added icon-unity
 - Added icon-d3
 - Added icon-angular
 - Added icon-angular-alt
 - Added icon-reactjs
 - Added icon-spring
 - Added icon-jquery
 - Added icon-backbone
 - Added icon-bootstrap
 - Added icon-freecodecamp
 - Added icon-sitefinity
 - Added icon-codeigniter
 - Added icon-codepen

#### 2.3.0 - 2016-03-01
 
 - Vagrant now used to automate setup of precise dev environment
 - cdnjs now hosting font-mfizz!
 - Added icon-angular
 - Added icon-grunt
 - Added icon-git
 - Added icon-spring

#### 2.2 - 2015-11-04

 - Improved build process (no new icons)

#### 2.1 - 2015-10-23

 - More documentation on adding your own icons
 - Revamped build process with [Blaze](https://github.com/fizzed/blaze)
 - Added icon-gradle
 - Added icon-exherbo
 - Added icon-maven
 - Added icon-plone
 - Added icon-archlinux
 - Added icon-gentoo
 - Added icon-docker

#### 2.0 - 2015-10-05

 - Revamped project to let others contribute icons directly
 - Merged in great work by David Parry (@suranyami)
 - DEVELOPMENT.md doc
 - New 'files' category for things like file types
 - Added icon-javascript-alt
 - Added icon-erlang
 - Added icon-elixir
 - Added icon-wordpress
 - Added icon-mongodb
 - Added icon-laravel
 - Added icon-symfony
 - Added icon-phone-gap
 - Added icon-svg

#### 1.2 - 2013-07-23

 - Moved project to GitHub
 - 14 new icons covering 12 new topics
 - Added icon-aws
 - Added icon-grails, grails-alt
 - Added icon-c
 - Added icon-haskell
 - Added icon-ruby-on-rails, icon-ruby-on-rails-alt
 - Added icon-clojure
 - Added icon-heroku
 - Added icon-dreamhost
 - Added icon-centos
 - Added icon-fedora
 - Added icon-mariadb
 - Added icon-redis

#### 1.1 - 2013-07-09

 - Added 20 new icons

#### 1.0 - 2013-06-29

 - Initial release
